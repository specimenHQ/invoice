# Building INVOICE as an Android APK (fully offline, no server)

This is a Capacitor project that wraps the whole book (`app/index.html`,
already self-contained with embedded fonts/audio) as a native Android app.
Once built, the APK runs with zero network access — everything is bundled
inside it.

## What you need on your own machine
- Android Studio (includes the Android SDK) — https://developer.android.com/studio
- That's it; Studio bundles its own JDK and Gradle.

## Steps
1. Unzip this project anywhere.
2. Open the `invoice-apk` folder in Android Studio ("Open" → pick the folder
   that contains `android/` — or open the `android/` subfolder directly).
3. Let Gradle sync (first sync downloads Android build tools — needs internet
   once, not afterward).
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
   The APK lands in `android/app/build/outputs/apk/debug/app-debug.apk`.
5. Copy that .apk to your phone (email, USB, Drive, whatever) and open it.
   Android will ask to allow installs from that source the first time —
   allow it, then install. No server, no wifi needed to run it afterward.

## To update later (new book build)
Every time you get a new `app/index.html` from me:
1. Replace `invoice-apk/www/index.html` with the new file.
2. In `invoice-apk/android`, run `../node_modules/.bin/cap sync android`
   (or from the project root: `npx cap sync android`).
3. Rebuild the APK in Android Studio (step 4 above).

## Command-line alternative (no Android Studio UI)
If you have the Android SDK installed and `ANDROID_HOME` set:
```
cd invoice-apk/android
./gradlew assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- This is a *debug* build — fine for installing on your own phone. A
  Play Store release needs a signed release build, which is a further step
  Android Studio walks you through (Build → Generate Signed Bundle/APK).
- `capacitor.config.json` sets the app id (`com.bill.invoice`) and name
  (`INVOICE`) — change those there if you want something else, then re-run
  `npx cap sync android`.
