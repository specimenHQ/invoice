package com.bill.invoice;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

  // Legacy path (pre-API 30) -- deprecated but still required on older devices.
  private static final int FULLSCREEN_FLAGS =
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
      | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
      | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
      | View.SYSTEM_UI_FLAG_FULLSCREEN
      | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

  // Single place that actually applies immersive mode, so every call site
  // (onCreate, onResume, onWindowFocusChanged, the layout listener) stays
  // in sync instead of drifting into three slightly different versions.
  private void applyImmersive() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      getWindow().setDecorFitsSystemWindows(false);
      WindowInsetsController ctrl = getWindow().getInsetsController();
      if (ctrl != null) {
        ctrl.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        ctrl.setSystemBarsBehavior(
            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
      }
    } else {
      getWindow().getDecorView().setSystemUiVisibility(FULLSCREEN_FLAGS);
    }
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    applyImmersive();

    final View decor = getWindow().getDecorView();
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      // re-hide if the system ever shows the bars back (edge swipe, dialog closing)
      decor.setOnApplyWindowInsetsListener((v, insets) -> {
        applyImmersive();
        return v.onApplyWindowInsets(insets);
      });
    } else {
      // re-hide only in reaction to the bars actually being shown (an edge
      // swipe, a system dialog closing) rather than on every focus event --
      // re-issuing this mid-touch was the suspect for the phone going
      // unresponsive on page 28, since that's exactly the moment a fresh
      // deviceorientation/touch listener also just mounted for the crate.
      decor.setOnSystemUiVisibilityChangeListener(visibility -> {
        if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) applyImmersive();
      });
    }
    // Belt-and-suspenders: some OEM launchers / the WebView attaching
    // asynchronously after onCreate returns can clear the flags once,
    // silently, before any of the listeners above ever fire. Catching the
    // very first layout pass closes that gap without re-fighting the
    // system on every single layout forever.
    decor.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
      private int calls = 0;
      @Override public void onGlobalLayout() {
        if (calls++ < 3) applyImmersive();
        else decor.getViewTreeObserver().removeOnGlobalLayoutListener(this);
      }
    });
  }

  // The book's own rule is "no resume -- quitting starts the book over,"
  // not "any interruption starts the book over." Those are different events
  // and the first version of this fix conflated them: it reloaded on every
  // onRestart(), which also fires if the screen times out (or is turned off
  // by an incoming call, etc.) and the reader simply turns it back on --
  // punishing an interruption they didn't choose. onUserLeaveHint() is
  // Android's actual signal for "the user chose to leave" (Home, the
  // app-switcher, opening another app) and does NOT fire for a screen
  // timeout or an incoming call taking focus. So: only arm the reload when
  // that hint has actually fired since the last time the book was showing.
  private boolean leftDeliberately = false;

  @Override
  protected void onUserLeaveHint() {
    super.onUserLeaveHint();
    leftDeliberately = true;
  }

  @Override
  public void onRestart() {
    super.onRestart();
    if (leftDeliberately) {
      leftDeliberately = false;
      if (getBridge() != null && getBridge().getWebView() != null) {
        getBridge().getWebView().reload();
      }
    }
  }

  @Override
  public void onResume() {
    super.onResume();
    applyImmersive();
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) applyImmersive();
  }
}
