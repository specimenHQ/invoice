package com.bill.invoice;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

  // Legacy path (pre-API 30) -- deprecated but still required on older devices.
  private static final int FULLSCREEN_FLAGS =
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
      | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
      | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
      | View.SYSTEM_UI_FLAG_FULLSCREEN
      | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      // Modern path: WindowInsetsController (API 30+)
      getWindow().setDecorFitsSystemWindows(false);
      WindowInsetsController ctrl = getWindow().getInsetsController();
      if (ctrl != null) {
        ctrl.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        ctrl.setSystemBarsBehavior(
            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
      }
      // re-hide if the system ever shows the bars back (edge swipe, dialog, etc)
      getWindow().getDecorView().setOnApplyWindowInsetsListener((v, insets) -> {
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
          c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        }
        return v.onApplyWindowInsets(insets);
      });
    } else {
      // Legacy path (pre-API 30)
      View decor = getWindow().getDecorView();
      decor.setSystemUiVisibility(FULLSCREEN_FLAGS);
      // re-hide only in reaction to the bars actually being shown (an edge
      // swipe, a system dialog closing) rather than on every focus event --
      // re-issuing this mid-touch was the suspect for the phone going
      // unresponsive on page 28, since that's exactly the moment a fresh
      // deviceorientation/touch listener also just mounted for the crate.
      decor.setOnSystemUiVisibilityChangeListener(visibility -> {
        if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
          decor.setSystemUiVisibility(FULLSCREEN_FLAGS);
        }
      });
    }
  }

  // The book's own rule: "No resume — quitting starts the book over." Android
  // doesn't reload the page just because the launcher icon was tapped again --
  // if the Activity was only backgrounded (not actually killed), it resumes
  // the exact same live WebView, mid-book, with the turn gate and everything
  // before it already resolved. That silently breaks the one rule the whole
  // design leans on. onRestart() fires whenever the Activity comes back from
  // being fully stopped (home button, app-switcher, another app on top) --
  // reload there so every re-entry is a true cold start, same as a fresh
  // launch. onCreate() alone doesn't catch this: it only runs once per
  // Activity instance, and Android keeps this Activity alive in the
  // background rather than recreating it.
  @Override
  protected void onRestart() {
    super.onRestart();
    if (getBridge() != null && getBridge().getWebView() != null) {
      getBridge().getWebView().reload();
    }
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (!hasFocus) return;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      WindowInsetsController ctrl = getWindow().getInsetsController();
      if (ctrl != null) {
        ctrl.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
      }
    } else {
      getWindow().getDecorView().setSystemUiVisibility(FULLSCREEN_FLAGS);
    }
  }
}
